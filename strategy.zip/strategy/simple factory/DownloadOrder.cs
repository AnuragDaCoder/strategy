﻿namespace strategypattern
{
    public interface IDownloadOrder
    {
        void Download(Order order);
    }

    public class XMLDownloadOrder : IDownloadOrder
    {
        public void Download(Order order)
        {
            Console.WriteLine("downloading order as xml");
        }
    }

    public class JSONDownloadOrder : IDownloadOrder
    {
        public void Download(Order order)
        {
            Console.WriteLine("downloading order as JSON");
        }
    }

    public class CSVDownloadOrder : IDownloadOrder
    {
        public void Download(Order order)
        {
            Console.WriteLine("downloading order as CSV");
        }
    }
}
