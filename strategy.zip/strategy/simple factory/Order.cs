﻿namespace strategypattern
{
    public class Order
    {
        public string OrderId { get; set; }
        public string ProductName { get; set; }
        public string ProductDisplayName { get; set; }
        public string ProductPrice { get; set; }
        public Order(string orderId, string productName, string productDisplayName, string productPrice)
        {
            OrderId = orderId;
            ProductName = productName;
            ProductDisplayName = productDisplayName;
            ProductPrice = productPrice;
            //you can set default value in the constructor
            //downloadOrderService = new JSONDownloadOrder;

            //or

            //directly pass as parameter to the constructor 
            //public Order(string orderId, string productName, string productDisplayName, string productPrice,IDownloadOrder downloadOrderService)
        }

        public void Download(IDownloadOrder downloadOrderService)
        {
            downloadOrderService.Download(this);
        }
    }

}
