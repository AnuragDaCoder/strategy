﻿// See https://aka.ms/new-console-template for more information



using strategypattern;

var order = new Order("123", "ps5", "ps5 console", "54990");
order.Download(new XMLDownloadOrder());

